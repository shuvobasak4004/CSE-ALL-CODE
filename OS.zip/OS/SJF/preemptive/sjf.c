#include<stdio.h>

int main()
{
    int at[] = {2,5,1,0,4}, bt[10] = {6, 2, 8, 3, 4}, temp[5], wt[5], endtime, tat[5];

    for(int i = 0; i < 5; i++)
    {
        temp[i] = bt[i];
    }

    int time, count = 0;
    for(time = 0; count!= 5; time++)
    {
        int smallest = 9;
        bt[smallest] = 999;

        for(int i = 0; i < 5; i++)
        {
            if(at[i] <= time && bt[i] < bt[smallest] && bt[i] > 0)
            {
                smallest = i;
            }
        }

        bt[smallest]--;
        if(bt[smallest]==0)
        {
            count++;
            endtime = time + 1;
            wt[smallest] = endtime - at[smallest] - temp[smallest];
            tat[smallest] = endtime - at[smallest];

        }
    }
    for(int i = 0; i < 5; i++)
    {
        printf("Turn Around Time is =%d \n",tat[i]);
    }
    printf(".....................\n");
    for(int i = 0; i < 5; i++)
    {

        printf("Waiting Time is =%d \n",wt[i]);
    }

}
