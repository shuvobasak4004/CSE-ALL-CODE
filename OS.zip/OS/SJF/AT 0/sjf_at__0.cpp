#include<stdio.h>
int main()
{
    int bt[3] = {4, 3, 5};
    int wt[3], tat[3], i, j, a = 0, total_wt = 0,total_tat = 0;
    double avg_wt, avg_tat;

    printf("Number of process is 3\n");

    for(int i = 0; i < 2; i++)
    {
        int pos = i;
        for(int j = i + 1; j < 4; j++)
        {
             if(bt[j] < bt[pos])
             {
                 pos = j;
             }
        }

        int temp = bt[i];
        bt[i] = bt[pos];
        bt[pos] = temp;

    }
    printf("Waiting time =0\n");

    for(i = 0; i < 2; i++)
    {
        a = a + bt[i];
        wt[i] = a;
        total_wt = total_wt + wt[i];
        printf("Waiting time =%d\n", wt[i]);

    }

    for(i = 0; i < 2; i++)
    {
        tat[i] = bt[i] + wt[i];
        total_tat = total_tat + tat[i];
        printf("Turn around time:%d\n", tat[i]);
    }

    avg_wt = total_wt / 3;
    printf("Average waiting time:%fl\n", avg_wt);

    avg_tat = total_tat / 3;
    printf("Average turn around time:%fl", avg_tat);

    return 0;



}

