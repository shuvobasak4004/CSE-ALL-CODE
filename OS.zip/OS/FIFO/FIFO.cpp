#include<bits/stdc++.h>
using namespace std;
int main()
{
    //int page[20]={7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1};
    int page[20]={2,3,2,1,5,2,4,5,3,2,5,2};
    int frame[3],tail=0,hit=0,miss=0;
    for(int i =0;i<20;i++)
    {
        int flag = 0;
        for(int j=0;j<3;j++ )
        {
          if(page[i]== frame[j])
          {
            flag =1;
          }

          }
          if(flag==1){
            hit++;
          }
        else
          {
             if(tail<=3){
            frame[tail]=page[i];
            tail++;
            miss++;
             }
             else{
                frame[0]=frame[1];
                frame[1]=frame[2];
                //frame[2]=frame[3];
                frame[2]= page[i];
                miss++;
             }

        }

    }
    cout<<"Hit = "<<hit<<endl;
    cout<<"Miss = "<<miss;

}

