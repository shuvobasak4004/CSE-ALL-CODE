#include<bits/stdc++.h>
using namespace std;
int main()
{
    int BT[] = {10,12,4,2,5}, AT[] = {5,4,1,7,0}, WT[5], TAT[5], ST[5], temp;

    for(int i = 0; i < 5; i++)
    {
        int pos = i;
        for(int j = i + 1; j < 5; j++)
        {
            if(AT[j] < AT[pos])
            {
                pos = j;

            }
        }

        int temp = AT[pos];
        AT[pos] = AT[i];
        AT[i] = temp;

        temp = BT[pos];
        BT[pos] = BT[i];
        BT[i] = temp;

        //cout<<"AT = "<<AT[i]<<endl;
        //cout<<"BT = "<< BT[i]<<endl;

     }

    int a = 0;
    double b = 0, c = 0;

    for( int i = 0; i < 5; i++)
    {
        a = a + BT[i];
        ST[i] = 0;
        ST[i] = a;

        //cout<<"ST = "<<ST[i]<<endl;

    }

    cout<<" WT= 0"<<endl;

    for(int i = 0; i < 4; i++)
    {
        WT[i] = ST[i] - AT[i+1];
        printf(" WT= %d\n", WT[i]);
        b = b + WT[i];

    }
    double avg_WT = b / 5;
    cout<<fixed<<endl;
    cout<<setprecision(1)<<" Average Waiting Time:"<<avg_WT<<endl;
    printf("\n");
    printf("\n");

    //printf(" -------\n");

    for(int i = 0; i < 5; i++)
    {
        TAT[i] = ST[i] - AT[i];
        printf(" TAT= %d\n", TAT[i]);
        c = c + TAT[i];
    }
    double avg_TAT = c / 5;
    cout<<fixed<<endl;
    cout<<setprecision(1)<<" Average Turn Around Time:"<<avg_TAT<<endl;




    return 0;


}
