#include<bits/stdc++.h>
using namespace std;
#define EPSILON 0.01


double func(double x)
{
    return (x*x*x )+(x*x)  + (x  +7);
}


void bisection(double a, double b)
{
    if (func(a) * func(b) >= 0)
    {
        cout << " not assumed ";
        return;
    }

    double c = a;
    while ((b-a) >= EPSILON)
    {

        c = (a+b)/2;


        if (func(c) == 0.0)
            break;


        else if (func(c)*func(a) < 0)
            b = c;
        else
            a = c;
    }
    cout << "The value of root is : " << c;

}


int main()
{



     double a,b,c,d,e,x1,x2;
     while(1)
     {
         cout<<endl;
   cout<<"Enter a= ";
   cin>>a;
   cout<<"Enter b = ";
   cin>>b;
   x1 = ((a*a*a)+(a*a)+(a+7));
   x2 = ((b*b*b)+(b*b)+(b+7));

   if((x1<x2)&&(x1*x2)<0)
   {
       cout<<"Right"<<endl;
       bisection(a, b);
       break;

   }
   else{
        cout<<" Again ";

   }

     }



    return 0;
}
