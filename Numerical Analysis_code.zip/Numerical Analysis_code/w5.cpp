#include<bits/stdc++.h>
using namespace std ;
int main()
{
   double a,b,c,d,e,x1,x2;
while (1)
{
   cout<<"Enter a= ";
   cin>>a;
   cout<<"Enter b = ";
   cin>>b;
   x1 = ((a*a*a)+(a*a)+(a+7));
   x2 = ((b*b*b)+(b*b)+(b+7));

   if((x1<x2)&&(x1*x2)<0)
   {
       cout<<"Right"<<endl;
       break ;
   }
   else{
        cout<<" Again ";

   }
}


   c = ((a+b)/2);
   d = ((c*c*c)+(c*c)+(c+7));

   if (x1*d >= 0)
    {
        cout << " \n  "<<endl;

    }

   else
   {
      cout<<"possible"<<endl;
   }

   for (int i = 0 ; i<= 10 ; i++)
   {
       if (x1*d<0)
       {
           b=d;
           cout<<b<<endl;
       }
       else{
        a = d;
        cout<<a<<endl;
       }
   }


   return 0;
}

