#include<iostream>
using namespace std;

int main()
{
    int pid[3] ={1,2,3}, wt[3], bt[3] = {15,3,3}, TA[3];

    wt[0] = 0;
    cout<<"wt is "<<wt[0]<<endl;
    for(int i = 1; i < 3; i++)
    {
        wt[i] = wt[i -1] + bt[i - 1];
        cout<<"wt is "<<wt[i]<<endl;

    }

    cout<<endl;

    TA[0] = bt[0];
    cout<<"TA is "<<TA[0]<<endl;

    for(int i = 1; i <3;i++)
    {
        TA[i] = wt[i] + bt[i];
        cout<<"TA is "<< TA[i]<<endl;
    }


}
